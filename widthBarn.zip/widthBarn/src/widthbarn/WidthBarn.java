package widthbarn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Stack;

public class WidthBarn {

    private short N; // число элементов строки высот
    private short[] Line; // массив элементов
    Stack<Short> stack; // вспомогательный стэк для вычисления индекса ограничения высоты при проходах по массиву Line налево и направо
    short[] L; // массивы индексов для вычисление ширины сарая
    short[] R;

    public short[] ReadFile(String filepath) { // чтение массива из файла с 1 строкой - размером массива, 2 строкой - числами массива - высотами        

        try {
            File inFile = new File(filepath);
            FileReader fr = new FileReader(inFile);
            BufferedReader reader = new BufferedReader(fr);
            String line0 = reader.readLine();
            N = Short.parseShort(line0);

            String line1[] = reader.readLine().split(" ");
            Line = new short[N];
            for (short i = 0; i < N; i++) {
                Line[i] = Short.parseShort(line1[i]);
            }

            for (short i = 0; i < Line.length; i++) {
                System.out.print(Line[i]);
                System.out.print(" ");
            }
            System.out.println("");

            fr.close();

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return Line;
    }

    public void calcWidth() { // вычисления массивов индексов при просмотре направо и налево
        R = new short[N];
        L = new short[N];
        stack = new Stack<>();
        for (short i = 0; i < N; i++) {
            while (!stack.isEmpty()) {
                if (Line[i] < Line[stack.peek()]) {
                    R[stack.pop()] = (short) (i - 1);
                } else {
                    break;
                }
            }
            stack.push(i);
        }
        while (!stack.isEmpty()) {
            R[stack.pop()] = (short) (N - 1);
        }

        stack = new Stack<>();
        for (short i = (short) (N - 1); i >= 0; i--) {
            while (!stack.isEmpty()) {
                if (Line[i] < Line[stack.peek()]) {
                    L[stack.pop()] = (short) (i + 1);
                } else {
                    break;
                }
            }
            stack.push(i);
        }
        while (!stack.isEmpty()) {
            L[stack.pop()] = 0;
        }

    }

    public void widthRes() { // вывод массивов индексов L и R
        System.out.println("");
        System.out.println("индекс");
        for (short i = 0; i < N; i++) {
            System.out.print("  " + "\u001B[47m" + "\u001B[37m" + i + "\u001B[0m");
        }
        System.out.println("");
        System.out.println("высота");
        for (short i = 0; i < N; i++) {
            System.out.print("  " + "\u001B[44m" + "\u001B[37m" + Line[i] + "\u001B[0m");
        }
        System.out.println("");
        System.out.println("L");
        for (short i = 0; i < N; i++) {
            System.out.printf("%3d", L[i]);
        }
        System.out.println("");
        System.out.println("R");
        for (short i = 0; i < N; i++) {
            System.out.printf("%3d", R[i]);
        }
        System.out.println("");
    }

    public static void main(String[] args) {

        WidthBarn wb1 = new WidthBarn();
        wb1.ReadFile("src\\widthbarn\\1.txt");
        wb1.calcWidth();
        wb1.widthRes();

    }

}
