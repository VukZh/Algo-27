package smallbarn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class SmallBarn {

    private boolean[][] inArray;
    private int Y, X;

    public boolean[][] ReadFile(String filepath) { // чтение массива из файла из 0 и 1 с разделителем " " в boolean[][] (true - 1, false - 0)
        inArray = null;

        try {
            File inFile = new File(filepath);
            FileReader fr = new FileReader(inFile);
            BufferedReader reader = new BufferedReader(fr);
            String[] line0 = reader.readLine().split(" ");
            X = Integer.parseInt(line0[0]);
            Y = Integer.parseInt(line0[1]);
            inArray = new boolean[Y][X];

            for (int i = 0; i < Y; i++) {
                String[] line = reader.readLine().split(" ");
                for (int j = 0; j < X; j++) {
                    if (!"0".equals(line[j])) {
                        inArray[i][j] = true;
                    }
                }
            }

//            for (int i = 0; i < Y; i++) {
//                System.out.println("");
//                for (int j = 0; j < X; j++) {
//                    System.out.print(inArray[i][j] + " - ");
//                }
//            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return inArray;
    }

/////////////////////////
    public void ReadFileNew(String filepath) { // чтение массива из файла с 1 строкой - 2 числа размера массива, 2 строкой - числом построек, 3... строками - координатами с разделителем " " в Coord

        try {
            File inFile = new File(filepath);
            FileReader fr = new FileReader(inFile);
            BufferedReader reader = new BufferedReader(fr);
            String[] line0 = reader.readLine().split(" ");
            X = Short.parseShort(line0[0]);
            Y = Short.parseShort(line0[1]);
            inArray = new boolean[Y][X];
            String line1 = reader.readLine();
            Short T = Short.parseShort(line1);

            for (int i = 0; i < T; i++) {
                String[] lineCoord = reader.readLine().split(" ");
                inArray[Short.parseShort(lineCoord[1])][Short.parseShort(lineCoord[0])] = true;
            }
//            for (Coord coord : map) {
//                System.out.println(coord.getX() + " " + coord.getY());
//            }
            fr.close();

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

/////////////////////////
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone(); //To change body of generated methods, choose Tools | Templates.
    }

//    public SmallBarn(boolean[][] inArray, int Y, int X, <any> ) {
//        this.inArray = inArray;
//        this.Y = Y;
//        this.X = X;
//        this.<error> = <error>;
//    }
    public SmallBarn() {
    }

    private int weightX(int x, int y) { // сколько 0 направо от X Y включая этот 0
        int weight = 0;
        while (x < X) {
            if (inArray[y][x]) {
                break;
            } else {
//                System.out.println("x " + x  + " y " + y);
                weight++;
                x++;
            }
        }
        return weight;
    }

    private int maxBarn(int x, int y) { // маскимальная площадь прямоугольника из 0 из текущей точки
        int stepY = 1;
        int limitX = weightX(x, y);
        int maxSquare = stepY * limitX;
//        System.out.println("");
//        System.out.println("1- " + maxSquare);
        for (int yI = y + 1; yI < Y; yI++) {
            stepY++;
            int weightXNewY = weightX(x, yI);
//            System.out.println("weightXNewY " + weightXNewY + " x "  + x + " yI " + yI);
            if (limitX > weightXNewY) {
                limitX = weightXNewY; // ограничение по X в мЕньшую сторону
            }
            int thisSquare = limitX * stepY; // площадь на данной итерации
            if (maxSquare < thisSquare) {
                maxSquare = thisSquare;
            }
//            System.out.println(" yI " + yI + " limitX " + limitX + " " +  " maxSquare " + maxSquare);
        }
        return maxSquare;
    }

    public int smallBarnRes() { // максимальная площадь из всех возможных
        int globalMaxSquare = 0;
        for (int i = 0; i < Y; i++) {
            for (int j = 0; j < X; j++) {
                int thisMaxSquare = maxBarn(j, i);
                if (globalMaxSquare < thisMaxSquare) {
                    globalMaxSquare = thisMaxSquare;
                }
            }
        }
        return globalMaxSquare;
    }

    public static void main(String[] args) {
        SmallBarn sb1 = new SmallBarn();
        sb1.ReadFile("src\\smallbarn\\1.txt");
        System.out.println("максимальный прямоугольник площадью " + sb1.smallBarnRes());

// тестируем быстродействие для сравнения с последним (динамический алгоритм) методом поиска, читаем файл другим методом из-за формата вх. данных из последнего метода(здесь около 2000 мс протиы 100 мс), 
        sb1.ReadFileNew("src\\smallbarn\\test_time_500.txt");
        long timeStartA2 = System.currentTimeMillis();
        sb1.smallBarnRes();
        long timeStopA2 = System.currentTimeMillis() - timeStartA2;
        System.out.println("время выполнения поиска максимальной площади для 500 * 500 " + timeStopA2 + " миллисекунд");
//        System.out.println("максимальный прямоугольник площадью " + sb1.smallBarnRes());

    }

}
