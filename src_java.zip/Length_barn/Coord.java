package lengthbarn;

public class Coord { // класс координат для HashSet

    private short x;
    private short y;

    Coord(short xTemp, short yTemp) {
        x = xTemp;
        y = yTemp;
    }

    public short getX() {
        return x;
    }

    public short getY() {
        return y;
    }

    @Override
    public boolean equals(Object o) { // проверка ключей по содержимому (для HashSet.contains)
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Coord otherObject = (Coord) o;
        if (otherObject.x != x || otherObject.y != y) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 11;
        hash = hash * 47 + x;
        hash = hash * 47 + y;
        return hash;
    }

}
