package lengthbarn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Math.random;
import java.util.HashSet;

public class LengthBarn {

    private short Y, X, T; // размеры матрицы и число построек

    private HashSet<Coord> map;

    private short[][] length;

    public HashSet<Coord> ReadFile(String filepath) { // чтение массива из файла с 1 строкой - 2 числа размера массива, 2 строкой - числом построек, 3... строками - координатами с разделителем " " в Coord
        map = new HashSet();

        try {
            File inFile = new File(filepath);
            FileReader fr = new FileReader(inFile);
            BufferedReader reader = new BufferedReader(fr);
            String[] line0 = reader.readLine().split(" ");
            X = Short.parseShort(line0[0]);
            Y = Short.parseShort(line0[1]);
            String line1 = reader.readLine();
            T = Short.parseShort(line1);

            for (int i = 0; i < T; i++) {
                String[] lineCoord = reader.readLine().split(" ");
                Coord newTree = new Coord(Short.parseShort(lineCoord[0]), Short.parseShort(lineCoord[1]));
                map.add(newTree);
            }

            for (Coord coord : map) {
                System.out.println(coord.getX() + " " + coord.getY());
            }
            fr.close();

//            for (int i = 0; i < Y; i++) {
//                System.out.println("");
//                for (int j = 0; j < X; j++) {
//                    System.out.print(inArray[i][j] + " - ");
//                }
//            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return map;
    }

    public void GenerateMap(int x, int y, int t, String filepath) { // генератор файла с 1 строкой - 2 числа размера массива, 2 строкой - числом построек, 3... строками - координатами с разделителем " " в Coord
        HashSet tmpHS;
        tmpHS = new HashSet<Coord>();
//        Coord newGenerateCoord;
        String[] outLines = new String[t + 2];
        outLines[0] = x + " " + y;
        outLines[1] = t + "";
        short xRandom, yRandom;
        for (int i = 0; i < t; i++) {
            Coord treeNew;
            do {
                xRandom = (short) (random() * x);
                yRandom = (short) (random() * y);
                treeNew = new Coord(xRandom, yRandom);
//                System.out.println(xRandom + " - " + yRandom);
            } while (tmpHS.contains(treeNew));
            tmpHS.add(treeNew);
            outLines[i + 2] = xRandom + " " + yRandom;
//            System.out.println("--- " + i);
        }

        try {
            File outFile = new File(filepath);
            FileWriter fw = new FileWriter(outFile);
            String resString = String.join("\n", outLines);
            fw.write(resString);
            fw.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void outMap() {
        for (short i = 0; i < Y; i++) {
            System.out.println("");
            for (short j = 0; j < X; j++) {
                System.out.print(map.contains(new Coord(j, i)) ? "█" : "○");
            }
        }
        System.out.println("");
    }

    public void calcLength() {
        length = new short[X][Y];
        for (short i = 0; i < Y; i++) {
            for (short j = 0; j < X; j++) {
                if (map.contains(new Coord(j, i))) {
                    length[j][i] = 0;
                } else if (i > 0) {
                    length[j][i] = (short) (length[j][i - 1] + 1);
                } else {
                    length[j][i] = (short) (length[j][i] + 1);
                }
//                    length[j][i]++;

            }
        }
    }

    public void outLength() {
        for (short i = 0; i < Y; i++) {
            System.out.println("");
            short j;
            for (j = 0; j < X - 1; j++) {
                System.out.printf("%3d", length[j][i]);
                System.out.print(" ");
            }
            System.out.printf("%3d", length[j][i]);
        }
        System.out.println("");
    }

    public static void main(String[] args) {

        LengthBarn lb1 = new LengthBarn();

        lb1.GenerateMap(30, 10, 40, "src\\lengthbarn\\1.txt");
        lb1.ReadFile("src\\lengthbarn\\1.txt");
        lb1.outMap();
        lb1.calcLength();
        lb1.outLength();

    }

}
