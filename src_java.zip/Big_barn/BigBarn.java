package bigbarn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Math.random;
import java.util.HashSet;
import java.util.Stack;

public class BigBarn {

    private short Y, X, T; // размеры матрицы и число построек
    private HashSet<Coord> map;
    private short[][] length; // матрица длин
    private int[][] square; // матрица площадей*

    public void ReadFile(String filepath) { // чтение массива из файла с 1 строкой - 2 числа размера массива, 2 строкой - числом построек, 3... строками - координатами с разделителем " " в Coord

        map = new HashSet();

        try {
            File inFile = new File(filepath);
            FileReader fr = new FileReader(inFile);
            BufferedReader reader = new BufferedReader(fr);
            String[] line0 = reader.readLine().split(" ");
            X = Short.parseShort(line0[0]);
            Y = Short.parseShort(line0[1]);
            String line1 = reader.readLine();
            T = Short.parseShort(line1);

            for (int i = 0; i < T; i++) {
                String[] lineCoord = reader.readLine().split(" ");
                Coord newTree = new Coord(Short.parseShort(lineCoord[0]), Short.parseShort(lineCoord[1]));
                map.add(newTree);
            }
//            for (Coord coord : map) {
//                System.out.println(coord.getX() + " " + coord.getY());
//            }
            fr.close();

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void GenerateMap(int x, int y, int t, String filepath) { // генератор файла с 1 строкой - 2 числа размера массива, 2 строкой - числом построек, 3... строками - координатами с разделителем " " в Coord
        HashSet tmpHS;
        tmpHS = new HashSet<Coord>();
//        Coord newGenerateCoord;
        String[] outLines = new String[t + 2];
        outLines[0] = x + " " + y;
        outLines[1] = t + "";
        short xRandom, yRandom;
        for (int i = 0; i < t; i++) {
            Coord treeNew;
            do {
                xRandom = (short) (random() * x);
                yRandom = (short) (random() * y);
                treeNew = new Coord(xRandom, yRandom);
//                System.out.println(xRandom + " - " + yRandom);
            } while (tmpHS.contains(treeNew));
            tmpHS.add(treeNew);
            outLines[i + 2] = xRandom + " " + yRandom;
//            System.out.println("--- " + i);
        }

        try {
            File outFile = new File(filepath);
            FileWriter fw = new FileWriter(outFile);
            String resString = String.join("\n", outLines);
            fw.write(resString);
            fw.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void outMap() { // вывод карты
        for (short i = 0; i < Y; i++) {
            System.out.println("");
            for (short j = 0; j < X; j++) {
                System.out.print(map.contains(new Coord(j, i)) ? "█" : "○");
            }
        }
        System.out.println("");
    }

    
    private void calcLength() { // подсчет длины сарая для всех ячеек X * Y
        length = new short[X][Y];
        for (short i = 0; i < Y; i++) {
            for (short j = 0; j < X; j++) {
                if (map.contains(new Coord(j, i))) {
                    length[j][i] = 0;
                } else if (i > 0) {
                    length[j][i] = (short) (length[j][i - 1] + 1);
                } else {
                    length[j][i] = (short) (length[j][i] + 1);
                }
            }
        }
    }
    
    public void outLength() { // вывод матрицы длин
        System.out.println("длины");
        for (short i = 0; i < Y; i++) {
            short j;
            for (j = 0; j < X - 1; j++) {
                System.out.printf("%3d", length[j][i]);
                System.out.print(" ");
            }
            System.out.printf("%3d", length[j][i]);
                        System.out.println("");
        }
        System.out.println("");
    }
    
    public int calcSquare(){ // подсчет максимальной площади сарая (и ширины для всех ячеек X * Y)
        
        int maxSquare = 0;
        square = new int[X][Y];
        short [] R = new short[X];
        short [] L = new short[X];
        short[] Line = new short[X];
        calcLength();
        
        for (short j = 0; j < Y; j++) {
            
            int tmpSquare;
            
            for (short i = 0; i < X; i++) {
                Line[i] = length[i][j];
            }
            
            Stack <Short> stack = new Stack<>();


            for (short i = 0; i < X; i++) {
                while (!stack.isEmpty()) {
                    if (Line[i] < Line[stack.peek()]) {
                        R[stack.pop()] = (short) (i - 1);
                    } else {
                        break;
                    }
                }
                stack.push(i);
            }
            while (!stack.isEmpty()) {
                R[stack.pop()] = (short) (X - 1);
            }

            stack = new Stack<>();
            for (short i = (short) (X - 1); i >= 0; i--) {
                while (!stack.isEmpty()) {
                    if (Line[i] < Line[stack.peek()]) {
                        L[stack.pop()] = (short) (i + 1);
                    } else {
                        break;
                    }
                }
                stack.push(i);
            }
            while (!stack.isEmpty()) {
                L[stack.pop()] = 0;
            }
            
            for (short i = 0; i < X; i++) {
                tmpSquare = (R[i] - L[i] + 1) * length[i][j];
                square[i][j] = tmpSquare;
                if (maxSquare < tmpSquare)
                    maxSquare = tmpSquare;
                
            }
        }
        return maxSquare;
    }

    public void outSquare() { // вывод матрицы площадей*
        System.out.println("площади");
        for (short i = 0; i < Y; i++) {
            short j;
            for (j = 0; j < X - 1; j++) {
                System.out.printf("%3d", square[j][i]);
                System.out.print(" ");
            }
            System.out.printf("%3d", square[j][i]);
            System.out.println("");
        }
        
    }


    
    


    public static void main(String[] args) {

        BigBarn lb1 = new BigBarn();
        lb1.GenerateMap(10, 3, 2, "src\\bigbarn\\test.txt");
        lb1.ReadFile("src\\bigbarn\\test.txt");
        lb1.outMap();    
        System.out.println("");
        System.out.println("максимальная площадь: " + lb1.calcSquare());
        System.out.println("");
        lb1.outLength();
        System.out.println("");
        lb1.outSquare();
        
        // тестируем быстродействие (около 15 с)
        
//        lb1.GenerateMap(10000, 10000, 20000, "src\\bigbarn\\test_time_10000.txt");
//        lb1.ReadFile("src\\bigbarn\\test_time_10000.txt");
//        long timeStartA1 = System.currentTimeMillis();
//        lb1.calcSquare();
//        long timeStopA1 = System.currentTimeMillis() - timeStartA1;
//        System.out.println("время выполнения поиска максимальной площади для 10000 * 10000 " + timeStopA1 + " миллисекунд");


        
        // тестируем быстродействие для сравнения с первым методом поиска (здесь около 100-150 мс)
        
        lb1.GenerateMap(500, 500, 2000, "src\\bigbarn\\test_time_500.txt");
        lb1.ReadFile("src\\bigbarn\\test_time_500.txt");
        long timeStartA2 = System.currentTimeMillis();
        lb1.calcSquare();
        long timeStopA2 = System.currentTimeMillis() - timeStartA2;
        System.out.println("время выполнения поиска максимальной площади для 500 * 500 " + timeStopA2 + " миллисекунд");
        
    }

}
